package com.example.stanh.flashbeepshake

import android.content.Context
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.media.ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.support.annotation.RequiresApi
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button

import kotlinx.android.synthetic.main.activity_main.*
@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    private var objCamManager: CameraManager ?= null
    private var mCamera: String ?= null
    private var ivOnOff: Button ?= null
    private var isTorchOn: Boolean ?= null

    private var vibrateButton: Button ?= null
    private var isVibOn: Boolean ?= null
    private var vibManager: Vibrator ?=null

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)



        ivOnOff = findViewById(R.id.flashButton)
        isTorchOn = false

        objCamManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager

        try {
            mCamera = objCamManager!!.cameraIdList[0]
        }
        catch (e:CameraAccessException){
            e.printStackTrace()
        }

        ivOnOff!!.setOnClickListener{
            try{
                if(isTorchOn!!){
                    turnOffLight()
                    isTorchOn = false
                }else{
                    turnOnLight()
                    isTorchOn = true
                }
            }catch (e:Exception){
                e.printStackTrace()
            }
        }

        vibrateButton = findViewById(R.id.vibButton)
        isVibOn = false

        vibManager = getSystemService(VIBRATOR_SERVICE) as Vibrator
        vibrateButton!!.setOnClickListener{
            try{
                if(isVibOn!!){
                    turnVibOff()
                    isVibOn = false
                }else{
                    turnVibOn()
                    isVibOn = true
                }
            }catch (e:Exception){
                e.printStackTrace()
            }
        }



    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when(item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    fun turnOnLight(){
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                objCamManager!!.setTorchMode(mCamera!!, true)
            }
        }
        catch (e:Exception){
            e.printStackTrace()
        }
    }

    fun turnOffLight(){
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                objCamManager!!.setTorchMode(mCamera!!, false)
            }
        }
        catch (e:Exception){
            e.printStackTrace()
        }
    }

    fun turnVibOff(){
        try{
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                vibManager!!.vibrate(100000000)
            }
        }
        catch (e:Exception){
            e.printStackTrace()
        }
    }

    fun turnVibOn(){
        try{
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                vibManager!!.cancel()
            }
        }
        catch (e:Exception){
            e.printStackTrace()
        }
    }

    fun beepNoise(view: View){
        val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 10000)
    }


}


